
package edu.buffalo.cse.cse486586.simpledynamo;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Comparator;
import java.util.Formatter;

import android.content.Context;
import android.telephony.TelephonyManager;

public class AvdNode implements Comparator<AvdNode> {
    String PRED;
    String myPort;
    String SUCC_1;
    String SUCC_2;
    String PRED_1;
    String PRED_2;
    String hashedVal;
    boolean coOrdinator;
    Context applicationContext = null;

    public AvdNode(Context context) {
        super();
        this.applicationContext = context;
    }

    public AvdNode() {
        super();

    }

    public String getMyPort() {
        TelephonyManager tel = (TelephonyManager)this.applicationContext
                .getSystemService(Context.TELEPHONY_SERVICE);
        String portStr = tel.getLine1Number().substring(tel.getLine1Number().length() - 4);
        return portStr;

    }

    private String genHash(String input) throws NoSuchAlgorithmException {
        MessageDigest sha1 = MessageDigest.getInstance("SHA-1");
        byte[] sha1Hash = sha1.digest(input.getBytes());
        Formatter formatter = new Formatter();
        for (byte b : sha1Hash) {
            formatter.format("%02x", b);
        }
        return formatter.toString();
    }

    @Override
    public int compare(AvdNode avd0, AvdNode avd1) {
        try {
            avd0.hashedVal = genHash(avd0.hashedVal);
            avd1.hashedVal = genHash(avd1.hashedVal);
        } catch (NoSuchAlgorithmException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return avd0.hashedVal.compareToIgnoreCase(avd1.hashedVal);
    }
}
