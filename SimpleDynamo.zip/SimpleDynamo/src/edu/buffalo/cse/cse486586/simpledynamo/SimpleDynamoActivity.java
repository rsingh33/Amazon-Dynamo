
package edu.buffalo.cse.cse486586.simpledynamo;

import android.app.Activity;
import android.os.Bundle;
import android.text.method.ScrollingMovementMethod;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;

public class SimpleDynamoActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_simple_dynamo);

        TextView tv = (TextView)findViewById(R.id.textView1);
        tv.setMovementMethod(new ScrollingMovementMethod());
        findViewById(R.id.button2).setOnClickListener(
                new OnTestClickListener(tv, getContentResolver()));

        Button button = (Button)findViewById(R.id.button1);
        button.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View arg0) {
                // TODO Auto-generated method stub
                TextView textView = (TextView)findViewById(R.id.textView2);
                textView.setText(SimpleDynamoProvider.PREDECESSOR_1 + " "
                        + SimpleDynamoProvider.PREDECESSOR_1 + " " + " "
                        + SimpleDynamoProvider.SUCCESSOR_1 + " " + SimpleDynamoProvider.SUCCESSOR_2);
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.simple_dynamo, menu);
        return true;
    }

}
