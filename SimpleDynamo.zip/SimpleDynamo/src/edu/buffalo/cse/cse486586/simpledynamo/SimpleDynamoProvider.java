
package edu.buffalo.cse.cse486586.simpledynamo;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.StreamCorruptedException;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketTimeoutException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.Formatter;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.MatrixCursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.database.sqlite.SQLiteQueryBuilder;
import android.net.Uri;
import android.telephony.TelephonyManager;
import android.util.Log;

public class SimpleDynamoProvider extends ContentProvider {
    volatile int querycounter = 0;
    static final String TAG = "dht";
    static final String REMOTE_PORT0 = "11108";
    static final String REMOTE_PORT1 = "11112";
    static final String REMOTE_PORT2 = "11116";
    static final String REMOTE_PORT3 = "11120";
    static final String REMOTE_PORT4 = "11124";
    static final String MYPORT_0 = "5554";
    static final String MYPORT_1 = "5556";
    static final String MYPORT_2 = "5558";
    static final String MYPORT_3 = "5560";
    static final String MYPORT_4 = "5562";
    static final int SERVER_PORT = 10000;
    private SQLiteDatabase sqlDb;
    private SQLiteOpenHelper dynamoHelper;
    static String globalCursor = "";
    static boolean keyqueryWait = false;
    public static String SUCCESSOR_1 = "";
    public static String SUCCESSOR_2 = "";
    public static String PREDECESSOR_1 = "";
    public static String PREDECESSOR_2 = "";
    public static String NODE_ID = "";
    int messageCount;
    static boolean nodeDown = false;
    static boolean queryWait = true;
    static int msgCont = 0;
    ArrayList<String> hold = new ArrayList<String>();
    Context context;
    ArrayList<AvdNode> list = new ArrayList<AvdNode>();
    Uri uri;
    int ri = 0;

    // String recoveryGlobal = "rahul";
    int count = 0;
    String globalKey = "";
    static boolean spin = true;
    static boolean insertSpin = true;
    static String coOrdinator;
    static String myPort;
    static String hashedPortNo = "";
    public static final Uri CONTENT_URI = Uri
            .parse("content://edu.buffalo.cse.cse486586.simpledynamo.provider");
    static boolean recoveryWait = true;
    String recoveryMessage = "";

    public static String newRecovery = "";
    public static boolean newRecFin = true;

    @Override
    public boolean onCreate() {

        dynamoHelper = new DynamoHelper(getContext());
        myPort = getMyPort();

        Log.d(TAG, "In on create and my port is " + myPort);
        context = getContext();
        try {
            hashedPortNo = genHash(myPort);
        } catch (NoSuchAlgorithmException e) {

            e.printStackTrace();
        }

        AvdNode node1 = new AvdNode(context);
        node1.myPort = "5562";
        try {
            node1.hashedVal = genHash("5562");
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        }
        node1.SUCC_1 = "5556";
        node1.SUCC_2 = "5554";
        node1.PRED_1 = "5560";
        node1.PRED_2 = "5558";

        list.add(node1);

        AvdNode node2 = new AvdNode(context);
        node2.myPort = "5556";
        try {
            node2.hashedVal = genHash("5556");
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        }
        node2.SUCC_1 = "5554";
        node2.SUCC_2 = "5558";
        node2.PRED_1 = "5562";
        node2.PRED_2 = "5560";

        list.add(node2);

        AvdNode node3 = new AvdNode(context);
        node3.myPort = "5554";
        try {
            node3.hashedVal = genHash("5554");
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        }
        node3.SUCC_1 = "5558";
        node3.SUCC_2 = "5560";
        node3.PRED_1 = "5556";
        node3.PRED_2 = "5562";

        list.add(node3);

        AvdNode node4 = new AvdNode(context);
        node4.myPort = "5558";
        try {
            node4.hashedVal = genHash("5558");
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        }
        node4.SUCC_1 = "5560";
        node4.SUCC_2 = "5562";
        node4.PRED_1 = "5554";
        node4.PRED_2 = "5556";

        list.add(node4);

        AvdNode node5 = new AvdNode(context);
        node5.myPort = "5560";
        try {
            node5.hashedVal = genHash("5560");
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        }
        node5.SUCC_1 = "5562";
        node5.SUCC_2 = "5556";
        node5.PRED_1 = "5558";
        node5.PRED_2 = "5554";

        list.add(node5);
        if (SimpleDynamoProvider.myPort.equals("5562")) {
            SUCCESSOR_1 = node1.SUCC_1;
            SUCCESSOR_2 = node1.SUCC_2;
            PREDECESSOR_1 = node1.PRED_1;
            PREDECESSOR_2 = node1.PRED_2;
        } else if (SimpleDynamoProvider.myPort.equals("5556")) {
            SUCCESSOR_1 = node2.SUCC_1;
            SUCCESSOR_2 = node2.SUCC_2;
            PREDECESSOR_1 = node2.PRED_1;
            PREDECESSOR_2 = node2.PRED_2;

        } else if (SimpleDynamoProvider.myPort.equals("5554")) {
            SUCCESSOR_1 = node3.SUCC_1;
            SUCCESSOR_2 = node3.SUCC_2;
            PREDECESSOR_1 = node3.PRED_1;
            PREDECESSOR_2 = node3.PRED_2;

        } else if (myPort.equals("5558")) {
            SUCCESSOR_1 = node4.SUCC_1;
            SUCCESSOR_2 = node4.SUCC_2;
            PREDECESSOR_1 = node4.PRED_1;
            PREDECESSOR_2 = node4.PRED_2;

        } else if (myPort.equals("5560")) {
            SUCCESSOR_1 = node5.SUCC_1;
            SUCCESSOR_2 = node5.SUCC_2;
            PREDECESSOR_1 = node5.PRED_1;
            PREDECESSOR_2 = node5.PRED_2;

        }
        // Collections.sort(list, new AvdNode());
        new Thread(new ServerTaskRunnable(null)).start();
        recovery();
        return false;
    }

    public void recovery() {
        Log.d(TAG, "Recovery called ");
        try {
            SQLiteDatabase sqlDb = dynamoHelper.getReadableDatabase();
            Cursor cursor = null;
            SQLiteQueryBuilder qb = new SQLiteQueryBuilder();
            qb.setTables(DynamoHelper.TABLE_NAME);
            String[] keyCol = { DynamoHelper.KEY, DynamoHelper.VALUE };
            cursor = sqlDb.query(DynamoHelper.TABLE_NAME, keyCol, null, null, null, null, null);
            Log.d("rec", "cursor count " + cursor.getCount());
            int RecCounter = 0;
            if (cursor.getCount() > 0) {
                RecCounter = sqlDb.delete(DynamoHelper.TABLE_NAME, null, null);

                Message message1 = new Message();
                message1.sender = SimpleDynamoProvider.myPort;
                message1.receiver = SimpleDynamoProvider.SUCCESSOR_1;
                message1.type = "recovery";
                new Thread(new ClientTaskRunnable(message1)).start();
                Log.d("rec", "message sent from recovery to successor : myport and succ is "
                        + SimpleDynamoProvider.myPort + "  " + SimpleDynamoProvider.SUCCESSOR_1);

                Log.d("rec", "above first while of recovery " + recoveryWait);
                while (recoveryWait) {
                }
                Log.d("rec", "below first while of recovery " + recoveryWait);

                keyFilter(recoveryMessage);
                recoveryMessage = "";
                recoveryWait = true;
                Log.d("rec", "keys has been inserted via key filter");

                Message message2 = new Message();
                message2.sender = myPort;
                message2.receiver = PREDECESSOR_1;
                message2.type = "recovery";
                new Thread(new ClientTaskRunnable(message2)).start();

                Log.d("rec",
                        "second message sent from recovery to first pred : myport and pred1 is "
                                + SimpleDynamoProvider.myPort + "  "
                                + SimpleDynamoProvider.PREDECESSOR_1);

                Log.d("rec", "above second while of recovery " + recoveryWait);

                while (recoveryWait) {
                }

                Log.d("rec", "below second while of recovery " + recoveryWait);

                keyFilter(recoveryMessage);
                Log.d("rec", "keys has been inserted via key filter");
                recoveryMessage = "";
                recoveryWait = true;

                Message message3 = new Message();
                message3.sender = myPort;
                message3.receiver = PREDECESSOR_2;
                message3.type = "recovery";
                new Thread(new ClientTaskRunnable(message3)).start();

                Log.d("rec",
                        "third message sent from recovery to second pred :myport and pred2 is "
                                + SimpleDynamoProvider.myPort + "  "
                                + SimpleDynamoProvider.PREDECESSOR_2);
                Log.d("rec", "above third while of recovery " + recoveryWait);

                while (recoveryWait) {
                }
                Log.d("rec", "below third while of recovery " + recoveryWait);

                keyFilter(recoveryMessage);
                Log.d("rec", "keys has been inserted via key filter");
                recoveryMessage = "";
                recoveryWait = true;
                Log.d("rec", "bottom of recovery");

            }
        } catch (Exception e) {
            e.printStackTrace();
            Log.d("rec", "Exception occured in recovery");
        }

    }

    @Override
    public synchronized int delete(Uri uri, String selection, String[] selectionArgs) {
        Log.d(TAG, "in delete");
        int counter = 0;
        Log.d(TAG, "in delete in the * part");
        counter = sqlDb.delete(DynamoHelper.TABLE_NAME, null, null);
        Log.d(TAG, "in delete in the * part value of counter is " + counter);
        for (int i = 0; i < list.size(); i++) {
            if (list.get(i).myPort.equals(SimpleDynamoProvider.myPort))
                continue;
            Message deleteMessage = new Message();
            deleteMessage.sender = SimpleDynamoProvider.myPort;
            deleteMessage.receiver = list.get(i).myPort;
            deleteMessage.content = "*";
            deleteMessage.type = "delete";
            new Thread(new ClientTaskRunnable(deleteMessage)).start();

        }
        return counter;

    }

    @Override
    public String getType(Uri uri) {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public synchronized Uri insert(Uri uri, ContentValues values) {
        Log.d(TAG, "in insert");
        this.uri = uri;
        String hashedKey;
        String key = (String)values.get("key");
        String value = (String)values.get("value");
        try {
            try {

                hashedKey = genHash(key);
                int k = 0;
                for (int i = 0; i < list.size(); i++) {
                    if (hashedKey.compareTo(list.get(i).hashedVal) <= 0) {
                        k = i;
                        break;
                    } else if (hashedKey.compareTo(list.get(4).hashedVal) > 0) {
                        k = 0;
                        break;
                    }

                }

                if (k == 3) {
                    Log.d(TAG, "I am in i = 3");
                    Message message1 = new Message();
                    message1.sender = SimpleDynamoProvider.myPort;
                    message1.receiver = list.get(3).myPort;
                    message1.type = "insert";
                    message1.content = key + ":" + value;
                    (new Thread(new ClientTaskRunnable(message1))).start();
                    // Log.d(TAG, "Inserting into my port " + list.get(3).myPort
                    // + " "
                    // + message1.content + " i = " + i);
                    Message message2 = new Message();
                    message2.sender = SimpleDynamoProvider.myPort;
                    message2.receiver = list.get(4).myPort;
                    message2.type = "insert";
                    message2.content = key + ":" + value;
                    (new Thread(new ClientTaskRunnable(message2))).start();
                    // Log.d(TAG, "Inserting into my first succ " +
                    // list.get(4).myPort
                    // + " " + message2.content + " i = " + i);

                    Message message3 = new Message();
                    message3.sender = SimpleDynamoProvider.myPort;
                    message3.receiver = list.get(0).myPort;
                    message3.type = "insert";
                    message3.content = key + ":" + value;
                    (new Thread(new ClientTaskRunnable(message3))).start();
                    // Log.d(TAG, "Inserting into second succ " +
                    // list.get(0).myPort + " "
                    // + message3.content + " i = " + i);
                    // Log.d(TAG, "I am in i = 3");
                    while (insertSpin) {
                        // Log.d(TAG, "In while loop 2");
                    }

                } else if (k == 4) {
                    // Log.d(TAG, "I am in i = 4");
                    Message message1 = new Message();
                    message1.sender = SimpleDynamoProvider.myPort;
                    message1.receiver = list.get(4).myPort;
                    message1.type = "insert";
                    message1.content = key + ":" + value;
                    (new Thread(new ClientTaskRunnable(message1))).start();
                    // Log.d(TAG, "Inserting into my port " + list.get(4).myPort
                    // + " "
                    // + message1.content + " i = " + i);
                    Message message2 = new Message();
                    message2.sender = SimpleDynamoProvider.myPort;
                    message2.receiver = list.get(0).myPort;
                    message2.type = "insert";
                    message2.content = key + ":" + value;
                    (new Thread(new ClientTaskRunnable(message2))).start();
                    // Log.d(TAG, "Inserting into my first succ " +
                    // list.get(0).myPort
                    // + " " + message2.content + " i = " + i);

                    Message message3 = new Message();
                    message3.sender = SimpleDynamoProvider.myPort;
                    message3.receiver = list.get(1).myPort;
                    message3.type = "insert";
                    message3.content = key + ":" + value;
                    (new Thread(new ClientTaskRunnable(message3))).start();
                    // Log.d(TAG, "Inserting into second succ " +
                    // list.get(1).myPort + " "
                    // + message3.content + " i = " + i);

                    while (insertSpin) {
                        // Log.d(TAG, "In while loop 3");
                    }

                } else {
                    // Log.d(TAG, "I am in generic case");
                    Message message1 = new Message();
                    message1.sender = SimpleDynamoProvider.myPort;
                    message1.receiver = list.get(k).myPort;
                    message1.type = "insert";
                    message1.content = key + ":" + value;
                    (new Thread(new ClientTaskRunnable(message1))).start();
                    // Log.d(TAG, "Inserting into my port " + list.get(i).myPort
                    // + " "
                    // + message1.content + " i = " + i);
                    Message message2 = new Message();
                    message2.sender = SimpleDynamoProvider.myPort;
                    message2.receiver = list.get(k + 1).myPort;
                    message2.type = "insert";
                    message2.content = key + ":" + value;
                    (new Thread(new ClientTaskRunnable(message2))).start();
                    // Log.d(TAG, "Inserting into my first succ " + list.get(i +
                    // 1).myPort
                    // + " " + message2.content + " i = " + i);

                    Message message3 = new Message();
                    message3.sender = SimpleDynamoProvider.myPort;
                    message3.receiver = list.get(k + 2).myPort;
                    message3.type = "insert";
                    message3.content = key + ":" + value;
                    (new Thread(new ClientTaskRunnable(message3))).start();
                    // Log.d(TAG, "Inserting into second succ " + list.get(i +
                    // 2).myPort + " "
                    // + message3.content + " i = " + i);

                    // Log.d(TAG, "In third insert");

                    while (insertSpin) {
                        // Log.d(TAG, "In while loop 4");
                    }

                }

                // }

            } catch (NoSuchAlgorithmException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();

            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return uri;
    }

    public void insertIn(Message message) {
        try {
            String[] msg = message.content.split(":");
            String key = msg[0];
            String value = msg[1];
            // Log.d(TAG, "in insert into succ " + key + value);

            ContentValues cv = new ContentValues();
            cv.put("key", key);
            cv.put("value", value);
            // System.out.println(key);
            // Log.d(TAG, "get writable database");
            sqlDb = dynamoHelper.getWritableDatabase();
            // Log.d(TAG, "after get writable database");
            sqlDb.insertWithOnConflict(DynamoHelper.TABLE_NAME, null, cv,
                    SQLiteDatabase.CONFLICT_REPLACE);
            // Log.d(TAG, "insert message sender and reciver " + " " +
            // message.sender + " "
            // + message.receiver);
            Message messageAck = new Message();
            messageAck.type = "ack";
            messageAck.receiver = message.sender;
            messageAck.sender = message.receiver;
            // Log.d(TAG, "ack message sender and reciver " + messageAck.sender
            // +
            // " "
            // + messageAck.receiver);
            new Thread(new ClientTaskRunnable(messageAck)).start();
            // Log.d(TAG, "ack message sender and reciver " + messageAck.sender
            // +
            // " "
            // + messageAck.receiver);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public synchronized Cursor query(Uri uri, String[] projection, String selection,
            String[] selectionArgs, String sortOrder) {
        Cursor cursor = null;
        Log.d(TAG, "In query ");
        try {
            MatrixCursor matrixCursor = new MatrixCursor(new String[] { DynamoHelper.KEY,
                    DynamoHelper.VALUE });

            SQLiteDatabase sqlDb = dynamoHelper.getReadableDatabase();

            SQLiteQueryBuilder qb = new SQLiteQueryBuilder();
            qb.setTables(DynamoHelper.TABLE_NAME);
            String[] keyCol = { DynamoHelper.KEY, DynamoHelper.VALUE };
            selectionArgs = new String[] { selection };

            if (selection.equals("@")) {
                Log.d(TAG, "Inside the query @ block");

                cursor = sqlDb.query(DynamoHelper.TABLE_NAME, keyCol, null, null, null, null, null);

                Log.d(TAG, "cursor count in @ is " + cursor.getCount());
                return cursor;
            } else if (selection.equals("*")) {
                Log.e(TAG, "I am in * query");
                MatrixCursor mx = new MatrixCursor(new String[] { DynamoHelper.KEY,
                        DynamoHelper.VALUE });
                int count123 = 0;
                for (int i = 0; i < list.size(); i++) {
                    Log.d(TAG, "Message * query sent to " + list.get(i).myPort);
                    queryWait = true;
                    Message message = new Message();
                    message.sender = SimpleDynamoProvider.myPort;
                    message.content = "*";
                    message.receiver = list.get(i).myPort;
                    message.type = "query";

                    new Thread(new ClientTaskRunnable(message)).start();
                    Log.e(TAG, "I am in * query sending message to " + list.get(i).myPort);
                    while (queryWait) {

                    }
                    Log.d(TAG, "control has come below while loop in query * ");
                    String[] arr = globalCursor.split(":");

                    String key = "";
                    String value = "";
                    for (int j = 0; j < arr.length / 2; j++) {
                        key = arr[count123];
                        count123++;
                        value = arr[count123];
                        count123++;

                        mx.addRow(new String[] { key, value });
                    }
                    Log.d(TAG, "I have finished adding the values to cursor in * query");
                    globalCursor = "";
                    querycounter = 0;
                    count123 = 0;

                }

                Log.d(TAG, "matrix query countyer in * is " + mx.getCount());
                return mx;

            } else {
                Log.d(TAG, "Query method In particular key query " + selection);
                MatrixCursor mx1 = new MatrixCursor(new String[] { DynamoHelper.KEY,
                        DynamoHelper.VALUE });
                if (querying(selection)) {
                    Log.d(TAG, "query methodkey is found in myself in paricular key " + selection);
                    selectionArgs = new String[] { selection };
                    cursor = sqlDb.query(DynamoHelper.TABLE_NAME, keyCol, keyCol[0] + "=?",
                            selectionArgs, null, null, null);
                    Log.d(TAG, "query method cursor in paricular key " + selection + " count :"
                            + cursor.getCount());
                    return cursor;

                } else {
                    Log.d(TAG, "query method I am in else part of part key query " + selection);
                    String hashedKey;

                    try {
                        hashedKey = genHash(selection);

                        int k = 0;
                        for (int i = 0; i < list.size(); i++) {
                            if (hashedKey.compareTo(list.get(i).hashedVal) <= 0) {
                                k = i;
                                break;
                            } else if (hashedKey.compareTo(list.get(4).hashedVal) > 0) {
                                k = 0;
                                break;
                            }

                        }

                        Message msgForSingleKey = new Message();
                        msgForSingleKey.sender = SimpleDynamoProvider.myPort;
                        msgForSingleKey.receiver = list.get(k).myPort;
                        msgForSingleKey.content = selection;
                        msgForSingleKey.type = "query";
                        (new Thread(new ClientTaskRunnable(msgForSingleKey))).start();
                        Log.d(TAG, "message to be sent first message  " + list.get(k).myPort
                                + "sending msg to it for key=" + selection);

                        queryWait = true;
                        while (queryWait) {
                        }
                        Log.d(TAG, "crossed while in else query method");

                        Log.d(TAG, "I am going to form the cursor it is the " + selection);
                        String[] arr1 = globalKey.split(":");
                        int count = 0;
                        String key = "";
                        String value = "";
                        if (!(globalKey.equals("") || globalKey.equals(null))) {
                            for (int i = 0; i < arr1.length / 2; i++) {

                                key = arr1[count];
                                count++;
                                value = arr1[count];
                                count++;
                                Log.d(TAG, "In the node");
                                Log.d(TAG, "key " + key);
                                Log.e(TAG, "value " + value);
                                mx1.addRow(new String[] { key, value });
                                return mx1;
                            }
                        } else if (keyqueryWait) {
                            Log.d(TAG,
                                    "else of particular key's else ready to send query to successor "
                                            + list.get((k)).SUCC_1 + " for key=" + selection);
                            Message msgForSingleKey1 = new Message();
                            msgForSingleKey1.sender = SimpleDynamoProvider.myPort;
                            msgForSingleKey1.receiver = list.get((k)).SUCC_1;
                            msgForSingleKey1.content = selection;
                            msgForSingleKey1.type = "query";
                            (new Thread(new ClientTaskRunnable(msgForSingleKey1))).start();

                            while (queryWait) {
                            }
                            Log.d(TAG, "response received from  successor for particular key"
                                    + list.get((k)).SUCC_1 + " for key=" + selection);
                            if (!(globalKey.equals("") || globalKey.equals(null))) {
                                String[] arr = globalKey.split(":");
                                int count3 = 0;
                                String key3 = "";
                                String value3 = "";
                                for (int i = 0; i < arr.length / 2; i++) {
                                    Log.d(TAG, "In the successor node");
                                    key3 = arr[count3];
                                    count3++;
                                    value3 = arr[count3];
                                    count3++;
                                    Log.d(TAG, "key " + key3);
                                    Log.e(TAG, "value " + value3);
                                    mx1.addRow(new String[] { key3, value3 });
                                    return mx1;
                                }
                            }
                        }
                        globalKey = "";
                        queryWait = true;
                        keyqueryWait = false;
                        Log.d(TAG,
                                "mx1 key is " + mx1.getColumnIndex(DynamoHelper.KEY)
                                + "mx1  value is  "
                                + mx1.getString(mx1.getColumnIndex(DynamoHelper.VALUE)));
                        return mx1;
                    } catch (NoSuchAlgorithmException e) {

                        e.printStackTrace();
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return cursor;
    }

    public boolean querying(String string) {
        String hashedKey;

        try {
            hashedKey = genHash(string);

            int k = 0;
            for (int i = 0; i < list.size(); i++) {
                if (hashedKey.compareTo(list.get(i).hashedVal) <= 0) {
                    k = i;
                    break;
                } else if (hashedKey.compareTo(list.get(4).hashedVal) > 0) {
                    k = 0;
                    break;
                }

            }
            if (SimpleDynamoProvider.myPort.equals(list.get(k))) {
                return true;
            }
        } catch (NoSuchAlgorithmException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return false;
    }

    @Override
    public int update(Uri uri, ContentValues values, String selection, String[] selectionArgs) {
        // TODO Auto-generated method stub
        return 0;
    }

    private String genHash(String input) throws NoSuchAlgorithmException {
        MessageDigest sha1 = MessageDigest.getInstance("SHA-1");
        byte[] sha1Hash = sha1.digest(input.getBytes());
        Formatter formatter = new Formatter();
        for (byte b : sha1Hash) {
            formatter.format("%02x", b);
        }
        return formatter.toString();
    }

    public String getMyPort() {
        TelephonyManager tel = (TelephonyManager)this.getContext().getSystemService(
                Context.TELEPHONY_SERVICE);
        String portStr = tel.getLine1Number().substring(tel.getLine1Number().length() - 4);
        return portStr;

    }

    class DynamoHelper extends SQLiteOpenHelper {
        public static final String DATABASE = "myDb.db";
        public static final String TABLE_NAME = "myTable";
        public static final int DB_VERSION = 8;
        public static final String KEY = "key";
        public static final String VALUE = "value";
        private String CREATE_TABLE = String.format("CREATE TABLE %s "
                + "(%s text primary key, %s text)", DynamoHelper.TABLE_NAME, DynamoHelper.KEY,
                DynamoHelper.VALUE);
        private Context context;

        static final String TAG = "DBHelper";
        private static final String DROP_TABLE = "DROP TABLE IF EXISTS " + TABLE_NAME;

        public DynamoHelper(Context context) {
            super(context, DynamoHelper.DATABASE, null, DynamoHelper.DB_VERSION);
            this.context = context;

        }

        @Override
        public void onCreate(SQLiteDatabase db) {
            // TODO Auto-generated method stub

            db.execSQL(CREATE_TABLE);

        }

        @Override
        public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
            // TODO Auto-generated method stub
            db.execSQL(DROP_TABLE);
            onCreate(db);
        }

    }

    private class ClientTaskRunnable implements Runnable {
        int host;
        Message msgToSend = new Message();

        public ClientTaskRunnable(Message message) {

            msgToSend = message;

        }

        @Override
        public void run() {
            // Log.d(TAG, "Client task is running::" + msgToSend);

            try {
                if (msgToSend.receiver.equals(MYPORT_0)) {
                    host = Integer.parseInt(REMOTE_PORT0);
                    Socket sock = new Socket();
                    try {
                        sock.setSoTimeout(1000);
                        sock.connect(new InetSocketAddress("10.0.2.2", host), 500);
                    } catch (SocketTimeoutException s) {
                        Log.d(TAG, "In sawe client exception");

                        queryWait = false;
                        keyqueryWait = true;
                        recoveryWait = false;
                        Log.d(TAG, "In client Task with stream exception recovery wait  "
                                + recoveryWait);
                        Log.d(TAG, "In client Task with stream exception querywait = " + queryWait);

                    }

                    ObjectOutputStream objectOutputStream = new ObjectOutputStream(
                            sock.getOutputStream());
                    objectOutputStream.writeObject(msgToSend);

                    sock.close();

                }

                else if (msgToSend.receiver.equals(MYPORT_1)) {
                    host = Integer.parseInt(REMOTE_PORT1);
                    Socket sock = new Socket();
                    try {
                        sock.setSoTimeout(1000);
                        sock.connect(new InetSocketAddress("10.0.2.2", host), 1500);
                    } catch (SocketTimeoutException s) {
                        Log.d(TAG, "In sawe client exception");
                        queryWait = false;
                        keyqueryWait = true;
                        recoveryWait = false;
                        Log.d(TAG, "In client Task with stream exception recovery wait  "
                                + recoveryWait);
                        Log.d(TAG, "In client Task with stream exception querywait = " + queryWait);

                    }
                    // sock.setSoTimeout(1000);
                    ObjectOutputStream objectOutputStream = new ObjectOutputStream(
                            sock.getOutputStream());
                    objectOutputStream.writeObject(msgToSend);

                    sock.close();

                }

                else if (msgToSend.receiver.equals(MYPORT_2)) {
                    host = Integer.parseInt(REMOTE_PORT2);
                    Socket sock = new Socket();
                    try {
                        sock.setSoTimeout(1000);
                        sock.connect(new InetSocketAddress("10.0.2.2", host), 1500);
                    } catch (SocketTimeoutException s) {
                        Log.d(TAG, "In sawe client exception");
                        queryWait = false;
                        keyqueryWait = true;
                        recoveryWait = false;
                        Log.d(TAG, "In client Task with stream exception recovery wait  "
                                + recoveryWait);
                        Log.d(TAG, "In client Task with stream exception querywait = " + queryWait);

                    }
                    // sock.setSoTimeout(1000);
                    ObjectOutputStream objectOutputStream = new ObjectOutputStream(

                            sock.getOutputStream());
                    objectOutputStream.writeObject(msgToSend);

                    sock.close();

                }

                else if (msgToSend.receiver.equals(MYPORT_3)) {
                    host = Integer.parseInt(REMOTE_PORT3);
                    Socket sock = new Socket();
                    try {
                        sock.setSoTimeout(1000);
                        sock.connect(new InetSocketAddress("10.0.2.2", host), 1500);
                    } catch (SocketTimeoutException s) {
                        Log.d(TAG, "In sawe client exception");
                        queryWait = false;
                        keyqueryWait = true;
                        recoveryWait = false;
                        Log.d(TAG, "In client Task with stream exception recovery wait  "
                                + recoveryWait);
                        Log.d(TAG, "In client Task with stream exception querywait = " + queryWait);

                    }
                    // sock.setSoTimeout(1000);
                    ObjectOutputStream objectOutputStream = new ObjectOutputStream(
                            sock.getOutputStream());
                    objectOutputStream.writeObject(msgToSend);

                    sock.close();

                } else if (msgToSend.receiver.equals(MYPORT_4)) {
                    host = Integer.parseInt(REMOTE_PORT4);
                    Socket sock = new Socket();
                    try {
                        sock.setSoTimeout(1000);
                        sock.connect(new InetSocketAddress("10.0.2.2", host), 1500);
                    } catch (SocketTimeoutException s) {
                        Log.d(TAG, "In sawe client exception");
                        queryWait = false;
                        keyqueryWait = true;
                        recoveryWait = false;
                        Log.d(TAG, "In client Task with stream exception recovery wait  "
                                + recoveryWait);
                        Log.d(TAG, "In client Task with stream exception querywait = " + queryWait);

                    }
                    // sock.setSoTimeout(1000);
                    ObjectOutputStream objectOutputStream = new ObjectOutputStream(
                            sock.getOutputStream());
                    objectOutputStream.writeObject(msgToSend);

                    sock.close();

                }

            } catch (StreamCorruptedException ex) {
                ex.printStackTrace();
                Log.d(TAG, "In Corrupted stream exception");
                queryWait = false;
                keyqueryWait = true;
                recoveryWait = false;
                Log.d(TAG, "In client Task with stream exception recovery wait  " + recoveryWait);
                Log.d(TAG, "In client Task with stream exception querywait = " + queryWait);

            } catch (SocketTimeoutException sc) {
                // insertSpin = false;
                sc.printStackTrace();
                queryWait = false;
                keyqueryWait = true;
                // newRecFin = false;
                recoveryWait = false;
                Log.d(TAG, "In client Task with stream exception recovery wait  " + recoveryWait);
                Log.d(TAG, "In client Task with stream exception querywait = " + queryWait);

                Log.d(TAG, "exception in SOCK excep is " + sc);

            } catch (IOException i) {
                i.printStackTrace();
                // insertSpin = false;
                queryWait = false;
                keyqueryWait = true;
                recoveryWait = false;

                Log.d(TAG, "In client Task with stream exception recovery wait  " + recoveryWait);
                Log.d(TAG, "In client Task with stream exception querywait = " + queryWait);

                Log.d(TAG, "exception in IO excep is " + i);

            } catch (NumberFormatException n) {

                n.printStackTrace();
            } catch (SecurityException s) {

            } catch (Exception e) {
                e.printStackTrace();
                keyqueryWait = true;
                queryWait = false;
                recoveryWait = false;

                Log.d(TAG, "General Exception in client task " + recoveryWait);

                Log.d(TAG, "exception in gene excep is " + e);
            }
        }
    }

    private class ServerTaskRunnable implements Runnable {

        Message msgReceived = new Message();

        public ServerTaskRunnable(Message message) {
            msgReceived = message;

        }

        @Override
        public void run() {
            // TODO Auto-generated method stub

            ServerSocket serverSocket = null;
            SimpleDynamoProvider.spin = false;
            try {
                serverSocket = new ServerSocket(10000);
                // serverSocket.setSoTimeout(100);

                Socket clientSocket;
                while (true) {
                    clientSocket = serverSocket.accept();

                    ObjectInputStream inputStream = new ObjectInputStream(
                            clientSocket.getInputStream());
                    msgReceived = (Message)inputStream.readObject();

                    clientSocket.close();
                    if (msgReceived.type.equals("insert")) {
                        insertIn(msgReceived);
                        Log.d(TAG, "message recived is insert " + msgReceived.sender + " "
                                + msgReceived.receiver);

                    } else if (msgReceived.type.equals("ack")) {
                        Log.d(TAG, "in ack message");
                        insertSpin = false;
                    } else if (msgReceived.type.equals("query")) {
                        if (msgReceived.content.equals("*")) {
                            // Log.d(TAG, "I ma in * query in server task");

                            String serializedCursor = "";
                            SQLiteDatabase sqlDb = dynamoHelper.getReadableDatabase();
                            Cursor cursor = null;
                            SQLiteQueryBuilder qb = new SQLiteQueryBuilder();
                            qb.setTables(DynamoHelper.TABLE_NAME);
                            String[] keyCol = { DynamoHelper.KEY, DynamoHelper.VALUE };
                            cursor = sqlDb.query(DynamoHelper.TABLE_NAME, keyCol, null, null, null,
                                    null, null);

                            cursor.moveToFirst();
                            serializedCursor = "";

                            Log.d(TAG, "" + cursor.getCount());
                            for (int i = 1; i <= cursor.getCount(); i++, cursor.moveToNext()) {

                                serializedCursor = serializedCursor

                                        + cursor.getString(cursor.getColumnIndex(DynamoHelper.KEY))
                                        + ":"
                                        + cursor.getString(cursor
                                                .getColumnIndex(DynamoHelper.VALUE)) + ":";

                            }

                            Message message = new Message();
                            message.sender = msgReceived.sender;
                            message.receiver = msgReceived.sender;
                            message.type = "queryResponse*";
                            message.content = serializedCursor;
                            (new Thread(new ClientTaskRunnable(message))).start();
                            Log.d(TAG,
                                    "I ma in * query in server task sending response to original sender  "
                                            + msgReceived.sender);
                        } else {
                            // //////////////////////////////////
                            Log.e(TAG, "I AM IN server task QUERY FOR EACH KEY");
                            SQLiteDatabase sqlDb = dynamoHelper.getReadableDatabase();
                            String[] columns = new String[] { DynamoHelper.KEY, DynamoHelper.VALUE };
                            Log.d(TAG, "HERE Lies the problem above the cursor");
                            Cursor cursor = sqlDb.query(DynamoHelper.TABLE_NAME, columns,
                                    columns[0] + "=?", new String[] { msgReceived.content }, null,
                                    null, null);
                            Log.d(TAG, "HERE Lies the problem below the cursor");

                            cursor.moveToFirst();
                            Message message = new Message();
                            message.sender = msgReceived.sender;
                            message.receiver = msgReceived.sender;
                            message.content = cursor.getString(cursor
                                    .getColumnIndex(DynamoHelper.KEY))
                                    + ":"
                                    + cursor.getString(cursor.getColumnIndex(DynamoHelper.VALUE));
                            message.type = "queryResponseKey";
                            Log.d(TAG, "HERE Lies the problem sending the message");

                            (new Thread(new ClientTaskRunnable(message))).start();
                            Log.d(TAG, "HERE Lies the problem  message is sent");

                        }
                    } else if (msgReceived.type.equals("queryResponse*")) {
                        Log.d(TAG, "* query response is recieved from " + msgReceived.sender);
                        globalCursor = msgReceived.content;
                        // querycounter++;
                        queryWait = false;
                        // Log.e(TAG, "globalCursor: " + globalCursor);

                    } else if (msgReceived.type.equals("queryResponseKey")) {
                        // Log.d(TAG, "key query response is recieved from " +
                        // msgReceived.content);

                        globalKey = msgReceived.content;

                        queryWait = false;
                        keyqueryWait = false;

                    } else if (msgReceived.type.equals("delete")) {
                        int deleteCounter = 0;
                        if (msgReceived.content.equals("*")) {

                            deleteCounter = sqlDb.delete(DynamoHelper.TABLE_NAME, null, null);
                            Log.d(TAG, "message received is delete in the * part in server task");

                        }

                    } else if (msgReceived.type.equals("recovery")) {
                        Log.d("rec", "message recieved is recovery in "
                                + SimpleDynamoProvider.myPort + " from " + msgReceived.sender);

                        String recoveryMessages = "";
                        SQLiteDatabase sqlDb = dynamoHelper.getReadableDatabase();
                        Cursor cursor = null;
                        SQLiteQueryBuilder qb = new SQLiteQueryBuilder();
                        qb.setTables(DynamoHelper.TABLE_NAME);
                        String[] keyCol = { DynamoHelper.KEY, DynamoHelper.VALUE };
                        cursor = sqlDb.query(DynamoHelper.TABLE_NAME, keyCol, null, null, null,
                                null, null);

                        cursor.moveToFirst();

                        Log.d("rec", "CUSRSOR COUNT IS " + cursor.getCount());
                        for (int i = 1; i <= cursor.getCount(); i++, cursor.moveToNext()) {
                            // Log.d(TAG, "I am collecting the keys here key " +
                            // cursor.getCount());
                            recoveryMessages = recoveryMessages
                                    + cursor.getString(cursor.getColumnIndex(DynamoHelper.KEY))
                                    + ":"
                                    + cursor.getString(cursor.getColumnIndex(DynamoHelper.VALUE))
                                    + ":";

                        }

                        Message message = new Message();
                        message.sender = SimpleDynamoProvider.myPort;
                        message.receiver = msgReceived.sender;
                        message.type = "recoveryResponse";
                        message.content = recoveryMessages;
                        (new Thread(new ClientTaskRunnable(message))).start();
                        Log.d("rec", "recoveryResponse message is sent by : " + message.sender
                                + "  " + message.receiver);

                    } else if (msgReceived.type.equals("recoveryResponse")) {
                        Log.d("recResp", "Recovery Response message recieved from "
                                + msgReceived.sender + " on " + msgReceived.receiver);
                        // Log.d("recResp", "message content is : " +
                        // msgReceived.content);
                        recoveryMessage = msgReceived.content;
                        recoveryWait = false;
                    }

                }

            } catch (IOException e1) {
                serverSocket = null;
                // TODO Auto-generated catch block
                e1.printStackTrace();
            } catch (ClassNotFoundException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }

        }
    }

    public void keyFilter(String string) {
        try {
            Log.d(TAG, "in Filter key");
            String[] arr = string.split(":");
            for (int x = 0; x < arr.length; x++) {
                System.out.println(arr[x]);
            }
            int count = 0;
            String key = "";
            String value = "";
            int keycount = 0;
            Log.d(TAG, "value of string in key is above if ");
            if (!((string.equals("") || (string.equals(null))))) {
                Log.d(TAG, "value of string in key in the if condition of filter is  ");
                for (int i = 0; i < arr.length / 2; i++) {

                    key = arr[count];
                    count++;
                    value = arr[count];
                    count++;

                    int loc = findKey(key);
                    if (list.get(loc).myPort.equals(SimpleDynamoProvider.myPort)
                            || list.get(loc).myPort.equals(SimpleDynamoProvider.PREDECESSOR_1)
                            || list.get(loc).myPort.equals(SimpleDynamoProvider.PREDECESSOR_2)) {
                        keycount++;
                        ContentValues cv = new ContentValues();

                        Log.d("rec", "Key " + key);
                        Log.e("rec", "value " + value);
                        cv.put("key", key);
                        cv.put("value", value);

                        sqlDb = dynamoHelper.getWritableDatabase();
                        sqlDb.insertWithOnConflict(DynamoHelper.TABLE_NAME, null, cv,
                                SQLiteDatabase.CONFLICT_REPLACE);
                    }
                    Log.d("rec", "no of keys inserted while recovery " + keycount);

                }

            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        count = 0;
    }

    public int findKey(String key) {
        int k = 0;
        String hashedKey;
        try {

            hashedKey = genHash(key);

            for (int i = 0; i < list.size(); i++) {
                if (hashedKey.compareTo(list.get(i).hashedVal) <= 0) {
                    k = i;
                    break;
                } else if (hashedKey.compareTo(list.get(4).hashedVal) > 0) {
                    k = 0;
                    break;
                }

            }
        } catch (NoSuchAlgorithmException e) {
        }
        return k;
    }

}
