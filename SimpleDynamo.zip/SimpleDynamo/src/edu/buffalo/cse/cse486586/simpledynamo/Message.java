
package edu.buffalo.cse.cse486586.simpledynamo;

import java.io.Serializable;

public class Message implements Serializable {

    private static final long serialVersionUID = 1L;
    String content;
    String type;
    String sender;
    String receiver;

    public Message() {
        // TODO Auto-generated constructor stub
        super();
    }

}
